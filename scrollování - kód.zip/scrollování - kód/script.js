const header = document.querySelector("header")
const heading = document.querySelector("h1")
const object = document.querySelector(".square")

window.addEventListener("scroll", () => {
    if (window.scrollY >= 100) {
        header.style.height = "60px"
        heading.style.lineHeight = "60px"
        heading.style.fontSize = "25px"
        object.style.display = "block"
    } else {
        header.style.height = "80px"
        heading.style.lineHeight = "80px"
        heading.style.fontSize = "32px"
    }
})

object.addEventListener("click", () => {
    window.scrollTo(0, 0)
})


